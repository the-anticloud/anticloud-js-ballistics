# Changelog

All notable changes to this project are documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to
[Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [3.1.0-rc.4] - 2026-10-01

### Changed
- Replace the Emscripten/Embind runtime with bclibc's standalone WebAssembly module and its flat C ABI. The JavaScript
  adapter now owns marshalling, memory lifetime and typed error conversion; the packaged bundle still contains the
  engine as a single base64-embedded JavaScript module.
- The module is built without C++ exceptions: bclibc's core never throws (every fallible call returns a result that the
  flat C ABI maps to an error code), so it needs no WebAssembly exception handling. The `engines.node >=24.15.0`
  requirement is gone; the whole suite passes on Node 22, and any WebAssembly host can run the module.
- Build the engine with zig (`uv run --with ziglang make build`, ~84 KB, the default) or wasi-sdk (`WASM_TOOLCHAIN=wasi-sdk
  WASI_SDK_PATH=...`, ~1 MB), and remove the Emscripten SDK submodule, its CI steps and the type dependency. The base64
  bundle shrinks from ~1.35 MB to ~112 KB with zig.
- Remove the last Emscripten leftovers (`lib/emsdk` include paths in `.vscode`, `emsdk/` and the generated `wasm/` in
  `.prettierignore`).
- Bump the `bclibc` submodule to its exception-free (`noexcept`) revision ([ballistics-lab/bclibc#40](https://github.com/ballistics-lab/bclibc/pull/40)),
  which also carries the flat-C-ABI interpolation functions (`BCLIBCFFI_hermite`, `BCLIBCFFI_interpolate_2pt`/`_3pt`, `BCLIBCFFI_interpolate_trajectory_data`).

## [3.1.0-rc.3] - 2026-09-25

### Chores
- Bump the `bclibc` submodule to `v2.0.0-rc.3`: it adds a bare-WebAssembly build of the core (one module that
  imports nothing, `make wasm` in `bclibc`, no Emscripten) and makes the engine's lock and the log work where there
  are no threads and no iostream. Nothing changes for this package: the embind bindings still build with Emscripten,
  and all the tests pass on the new core.

## [3.1.0-rc.2] - 2026-09-24

### Chores
- Bump the `bclibc` submodule to `v2.0.0-rc.2`'

## [3.1.0-rc.1] - 2026-09-22

### Changed
- Bump the `bclibc` submodule to `v2.0.0-rc.1`: the embedded RK45 methods'
  per-method tolerance/stats API (thread-local, shared by every engine on a
  thread using the same method) is replaced by stateful
  `BCLIBC_CashKarpIntegrator`/`BCLIBC_DormandPrinceIntegrator`/
  `BCLIBC_TsitourasIntegrator` classes. No functional change here — the WASM
  FFI layer only ever assigns the plain `BCLIBC_integrate*` free functions
  (unchanged, default `1e-6`/`1e-6` tolerances, no exposed step stats), never
  the tolerance/stats API this replaces.

## [3.1.0-beta.2] - 2026-09-21

### Added
- `IntegrationMethod.TSITOURAS`: Tsitouras 5(4) ("Tsit5") adaptive integration
  method, wrapping [bclibc](https://github.com/ballistics-lab/bclibc)'s new
  `BCLIBC_integrateTsitouras`. Exposed through the WASM bindings
  (`_IntegrationMethod`), `IntegrationMethod` in `src/_wasm.ts` and the type
  stubs, and added to the integration-method test matrix. Structurally
  identical to `DOPRI` (same 7-stage FSAL shape and step controller), with the
  same default calculation step (`0.0025`). Accuracy and step counts are
  comparable to `DOPRI` for smooth trajectories.

### Changed
- Bump the `bclibc` submodule to pick up `BCLIBC_integrateTsitouras`.

## [3.1.0-beta.1] - 2026-09-18

### Changed
- Pin `bclibc` to `v2.0.0-beta.7`, including the zero-point FFI/WASM export
  fixes used by `Calculator.aimingSolutionForTarget`.
- Add `Calculator.aimingSolutionForTarget` method
- `HitResult.trajectory` is replaced by three views to match
  `bclibc@2.0.0-beta.4`: `records` (the complete, exact chronological output —
  every scheduled sample and every physical event, each its own row; now what
  `length`, iteration, and `at()` read from), `samples` (the deterministic
  RANGE/TIME schedule table — a sample is annotated with an event's flag only
  when the two are the same instant to floating-point precision, never merely
  the nearest one, so a coarse schedule doesn't smear every event onto one
  row), and `events` (exact ZERO/MACH/APEX/MRT rows). `flag()` and `zeros()`
  now search `events` for event flags.

### Deprecated
- `HitResult.trajectory`: alias for `HitResult.records`, kept for source
  compatibility with the pre-`bclibc@2.0.0-beta.1` API. Logs a one-time
  `console.warn`. Use `.records` for the exact chronological stream, or
  `.samples` for the deterministic scheduled-sample table (what `.trajectory`
  used to mean).

## [3.0.0] - 2026-09-10

First stable release of the 3.x line. It promotes `3.0.0-rc.2` unchanged: no
source, binding or test changes were made after that tag, only toolchain and CI
updates. The prerelease sections below stay as the detailed record; the summary
here is what changed relative to the previous published release, `2.2.0-beta.2`.

### Highlights since `2.2.0-beta.2`

- **Breaking:** trajectories are now solved by the WASM build of
  [bclibc](https://github.com/ballistics-lab/bclibc) (pinned to `v1.1.7`); the
  pure-TypeScript integrator is gone and a WASM build is required
- **Breaking:** `WasmManager.init()` must be awaited before any calculation, and
  `Calculator.fire()`, `setWeaponZero()`, `HitResult.getAt()` and
  `HitResult.dangerSpace()` are asynchronous
- `IntegrationMethod` with three solvers: `RK4` (default), `EULER` and
  `VELOCITY_VERLET`
- `HitResult.getAt()` trajectory interpolation, `HitResult.flag()` point lookup,
  and `HitResult.dangerSpace()` returning a `DangerSpace`
- `TrajFlag` enum: `NONE`, `ZERO_UP`, `ZERO_DOWN`, `ZERO`, `MACH`, `RANGE`,
  `APEX`, `ALL`, `MRT`
- Tag-driven release pipeline: draft GitHub Release, manual approval, npm
  publish with provenance, and ESM + CJS smoke tests run against the packed
  tarball

### Changed

- Pin `lib/emsdk` submodule to `6.0.8` (local development toolchain only — CI
  and release builds use Emscripten `5.0.7` via `setup-emsdk`)
- npm dev-dependency updates

### CI

- `coverage.yml`: authenticate to Codecov with OIDC instead of a token

## [3.0.0-rc.2] - 2026-07-24

### Added

- `IntegrationMethod.VELOCITY_VERLET` — third integration method alongside `RK4`
  and `EULER`, exposed through `wasm/bindings.cpp`

### Changed

- Pin `bclibc` submodule to `v1.1.7`

## [3.0.0-rc.1] - 2026-07-21

### Added

- `.github/workflows/coverage.yml`: runs `jest --coverage` and uploads the
  report to Codecov via `codecov/codecov-action@v5`
- Codecov badge in README

### Changed

- npm dependencies upgrade
- eslint dependency upgrade
- README: badges and links converted to reference-style, consolidated under a
  `REUSABLE LINKS` section; `Related projects` rewritten as a short mention of
  the Ballistics Lab ecosystem
- Pin `bclibc` submodule to `v1.1.5`

### Fixed

- Type annotations fixes

## [3.0.0-beta.4] - 2026-07-03

Maintenance release: no source or API changes.

### Added

- `gitsubmodule` ecosystem in `.github/dependabot.yml` so `lib/bclibc` and
  `lib/emsdk` get automatic update PRs

### Changed

- `__stubs__/bclibc.d.ts` reformatted with Prettier (generated file, no API
  change)
- Bump `actions/cache` v5 → v6 in the test and release workflows

## [3.0.0-beta.3] - 2026-06-26

### Changed

- Bump `emscripten-core/setup-emsdk` to `v16`
- Bump `bclibc` to `v1.1.4`

## [3.0.0-beta.2] - 2026-06-02

### Added

- `eslint.config.js` flat config (ESLint v9/v10 format); replaces
  `.eslintignore` + old rc-style config
- `@typescript-eslint/parser` and `@typescript-eslint/eslint-plugin` dev
  dependencies for TypeScript linting
- `github-actions` ecosystem in `.github/dependabot.yml` for automatic GitHub
  Actions version updates
- `Development` section in README: prerequisites, clone, Emscripten setup, build
  commands, test, lint, deploy

### Changed

- Upgraded ESLint `^9` → `^10`
- Upgraded TypeScript `^5.9` → `^6.0`
- `tsconfig.json`: removed deprecated `baseUrl` (TS6), added
  `ignoreDeprecations: "6.0"` (silences tsup DTS build) and explicit
  `rootDir: "./"` (required by TS6 when ts-jest compiles `__tests__/` alongside
  `src/`)
- `__stubs__/bclibc.d.ts` rewritten to match real Emscripten-generated types:
  all enum types are now numeric unions (`_TrajectoryDataInterpKey`,
  `_TerminationReason`, etc.), `_HitOutput` field renamed `termination_reason` →
  `reason`, full `_TrajectoryData`, `_BaseTrajData`, `_Vector`, `_WindList`,
  `_DragTable` and `EmbindModule` interfaces added
- `Makefile` `build-wasm` target now copies
  `build/bclibc.d.ts → __stubs__/bclibc.d.ts` automatically so the stub stays in
  sync with the WASM API without manual maintenance

### Fixed

- `src/trajectory_data.ts`: `getAt()` parameter type corrected to
  `_TrajectoryDataInterpKey` (was accidentally widened to `number`);
  `hit.reason` field reference restored (was incorrectly changed to
  `hit.termination_reason`)
- `package-lock.json` added to `.gitignore` (project uses Yarn; npm lock file
  was polluting the working tree)

## [3.0.0-beta.1] - 2026-06-02

### Added

- WASM-based ballistic calculation engine powered by
  [bclibc](https://github.com/ballistics-lab/bclibc) C++ library
- `RK4` (Runge-Kutta 4th order) and `EULER` integration methods via
  `IntegrationMethod` enum
- `WasmManager` singleton for lazy WASM module initialisation
- `bclibc` added as a Git submodule at `lib/bclibc`
- Trajectory data interpolation via `HitResult.getAt()` with
  `_TrajectoryDataInterpKey`
- `TrajFlag` enum: `RANGE`, `ZERO_DOWN`, `ZERO_UP`, `ALL`, `NONE` and more
- `HitResult.flag()` helper to extract a single trajectory point by flag
- `HitResult.dangerSpace(atRange, targetHeight)` — computes the near/far range
  interval where a target of given height would be hit; returns a `DangerSpace`
  object with `begin` and `end` `TrajectoryData` points
- `DangerSpace` class with `begin`, `end`, and `target` `TrajectoryData` fields
- `__stubs__/bclibc.js` WASM stub so pure-TS tests run without a compiled WASM
  build
- `__tests__/wasmAvailable.ts` helper: exports `WASM_AVAILABLE` flag and
  skip-aware `testWasm` / `describeWasm`

### Changed

- **Breaking:** Calculation engine now requires a WASM build
  (`make build-wasm`); `Calculator` wraps `bclibc` instead of the pure-TS
  integrator
- `Shot` bindings aligned with bclibc v1.1.2: `BCLIBC_Shot::to_shot_props()` now
  handles `Atmosphere` and `Coriolis` pre-computation internally, reducing
  JS-side boilerplate
- All WASM-dependent test suites conditionally skip when `build/bclibc.js` is
  absent
- `atmosphere.test.ts` density precision relaxed from `4` → `3` decimal places
  to account for JS vs Python numeric differences
- `incomplete-shot.test.ts` height check at 1000 ft loosened from
  `toBeCloseTo(0, 2)` to `Math.abs(...) < 1.0 ft` to accommodate JS/Python
  solver divergence

### Fixed

- Removed unused JS-side dependencies after engine migration to WASM
- `HitResult.getAt()`: `getKeyVal` was returning `rawValue` for all dimensioned
  types; `Distance.rawValue` is stored in inches while WASM fields and all
  callers use feet, causing a 12× search mismatch that broke `dangerSpace()` and
  any custom `getAt()` call on distance/height/slant attributes. Fixed by using
  the WASM-native accessor (`.foot`, `.fps`, `.rad`, `.footPound`, `.pound`) for
  each key

### CI

- Build WASM with Emscripten 5.0.7 before running Jest (`make build-wasm`)
- Added `emscripten-core/setup-emsdk@v15` step with `actions/cache@v5` for emsdk
  caching
- Added `lib/emsdk/emsdk_env.sh` stub for Makefile compatibility (mirrors
  `release.yml`)
- Concurrency group (`github.workflow`-`github.ref`) with
  `cancel-in-progress: true`
- Added `emsdk-cache` to Jest `testPathIgnorePatterns` and
  `transformIgnorePatterns`
- Explicit `testMatch` glob (`**/__tests__/**/*.test.[jt]s?(x)`) prevents helper
  files and emsdk's own test files from being picked up as test suites

## [2.2.0-beta.2] - 2025-10-07

### Added

- Incomplete shots: trajectories that do not reach the requested range are
  returned with a terminal point; `HitResult.error` carries the stop reason

### Changed

- Bumped `jest` to 30.2.0
- Bumped `ts-jest`, `@babel/preset-env`, `prettier` to latest versions

### CI

- Added `dependabot.yml` with grouped npm dependency updates

## [2.0.0] - 2024-11-27

### Added

- Full v2 API aligned with
  [py-ballisticcalc](https://github.com/o-murphy/py-ballisticcalc) Python
  library
- `UNew` unit factory with `Distance`, `Velocity`, `Temperature`, `Pressure`,
  `Angular` and more
- `Atmo` with `Atmo.standard()`, `densityRatio`, `mach`, humidity and altitude
  support
- Multi-BC drag model (`DragModel` with `bcPoints`)
- `Wind`, `Weapon`, `Shot` typed data classes
- `Calculator` interface: `fire()`, zeroing, `getAtDistance()`
- `HitResult` / `TrajectoryData` typed result objects
- Comprehensive test suite: atmosphere, trajectory, computer, MBC, zero-finding,
  incomplete shots, danger space

### Changed

- **Breaking:** Complete rewrite from plain JS to TypeScript with strict typing
- **Breaking:** Package API v2.x is incompatible with v1.x

## [1.1.2] - 2023-12-29

### Fixed

- Type annotation fixes

### Changed

- Encapsulated trajectory calculation internals

## [1.1.1] - 2023-12-25

### Fixed

- Include `.d.ts` type declaration files in the published package

## [1.1.0] - 2023-12-25

### Added

- First stable TypeScript release (identical to `v1.0.3-beta.5`)

## [1.0.3-beta.5] - 2023-12-21

### Added

- TypeScript reimplementation (`v1.0.3-beta.1`)
- Multi-BC (`bcPoints`) support with debug fixes
- `DragDataPoint` type corrections

## [1.0.3-alpha.6] - 2023-12-17

### Fixed

- Multi-BC (`bcPoints`) debug and fix

---

[Unreleased]: https://github.com/o-murphy/js-ballistics/compare/v3.1.0-rc.4...HEAD
[3.1.0-rc.4]: https://github.com/o-murphy/js-ballistics/compare/v3.1.0-rc.3...v3.1.0-rc.4
[3.1.0-rc.3]: https://github.com/o-murphy/js-ballistics/compare/v3.1.0-rc.2...v3.1.0-rc.3
[3.1.0-rc.2]: https://github.com/o-murphy/js-ballistics/compare/v3.1.0-rc.1...v3.1.0-rc.2
[3.1.0-rc.1]: https://github.com/o-murphy/js-ballistics/compare/v3.1.0-beta.2...v3.1.0-rc.1
[3.1.0-beta.2]: https://github.com/o-murphy/js-ballistics/compare/v3.1.0-beta.1...v3.1.0-beta.2
[3.1.0-beta.1]: https://github.com/o-murphy/js-ballistics/compare/v3.0.0...v3.1.0-beta.1
[3.0.0]: https://github.com/o-murphy/js-ballistics/compare/v3.0.0-rc.2...v3.0.0
[3.0.0-rc.2]: https://github.com/o-murphy/js-ballistics/compare/v3.0.0-rc.1...v3.0.0-rc.2
[3.0.0-rc.1]: https://github.com/o-murphy/js-ballistics/compare/v3.0.0-beta.4...v3.0.0-rc.1
[3.0.0-beta.4]: https://github.com/o-murphy/js-ballistics/compare/v3.0.0-beta.3...v3.0.0-beta.4
[3.0.0-beta.3]: https://github.com/o-murphy/js-ballistics/compare/v3.0.0-beta.2...v3.0.0-beta.3
[3.0.0-beta.2]: https://github.com/o-murphy/js-ballistics/compare/v3.0.0-beta.1...v3.0.0-beta.2
[3.0.0-beta.1]: https://github.com/o-murphy/js-ballistics/compare/v2.2.0-beta.2...v3.0.0-beta.1
[2.2.0-beta.2]: https://github.com/o-murphy/js-ballistics/compare/v2.0.0...v2.2.0-beta.2
[2.0.0]: https://github.com/o-murphy/js-ballistics/compare/v1.1.2...v2.0.0
[1.1.2]: https://github.com/o-murphy/js-ballistics/compare/v1.1.1...v1.1.2
[1.1.1]: https://github.com/o-murphy/js-ballistics/compare/v1.1.0...v1.1.1
[1.1.0]: https://github.com/o-murphy/js-ballistics/compare/v1.0.3-beta.5...v1.1.0
[1.0.3-beta.5]: https://github.com/o-murphy/js-ballistics/compare/v1.0.3-alpha.6...v1.0.3-beta.5
[1.0.3-alpha.6]: https://github.com/o-murphy/js-ballistics/releases/tag/v1.0.3-alpha.6
