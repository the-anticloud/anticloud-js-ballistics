import { expect, describe, test, beforeAll } from "@jest/globals";
import { WASM_AVAILABLE } from "./wasmAvailable";
import { methods } from "./integrationMethods";
import {
    UNew,
    DragModel,
    DragTables,
    Ammo,
    Weapon,
    DragModelMultiBC,
    BCPoint,
    TrajectoryData,
} from "../src";
import { Calculator } from "../src/interface";
import { Shot } from "../src/shot";

describe("BCPoint validation", () => {
    test("bc_zero_throws", () => {
        /** BC must be positive */
        expect(() => new BCPoint({ BC: 0.0, Mach: 1.0 })).toThrow();
    });

    test("both_mach_and_v_throws", () => {
        /** Cannot specify both Mach and V */
        expect(() => new BCPoint({ BC: 0.1, Mach: 1.0, V: UNew.MPS(300) })).toThrow();
    });

    test("neither_mach_nor_v_throws", () => {
        /** Must specify either Mach or V */
        expect(() => new BCPoint({ BC: 0.1 })).toThrow();
    });
});

(WASM_AVAILABLE ? describe : describe.skip).each(methods)("TestMultiBC $name", (obj) => {
    const { method } = obj;
    let range = 1000;
    let step = 100;
    let dm = new DragModel({ bc: 0.22, dragTable: DragTables.G7 });
    let ammo = new Ammo({ dm: dm, mv: UNew.FPS(2600) });
    let weapon = new Weapon({ sightHeight: 4, twist: 12 });
    let calc = new Calculator({ method });
    let baseLineShot = new Shot({ weapon: weapon, ammo: ammo });
    let baselineTrajectory: TrajectoryData[];

    beforeAll(async () => {
        const hit = await calc.fire({
            shot: baseLineShot,
            trajectoryRange: range,
            trajectoryStep: step,
        });
        baselineTrajectory = hit.samples;
    });

    test("mbc1", async () => {
        const dmMulti = DragModelMultiBC({
            bcPoints: [
                new BCPoint({ BC: 0.22, V: UNew.FPS(2500) }),
                new BCPoint({ BC: 0.22, V: UNew.FPS(1500) }),
                new BCPoint({ BC: 0.22, Mach: 3 }),
            ],
            dragTable: DragTables.G7,
        });
        const multiShot = new Shot({
            weapon: weapon,
            ammo: new Ammo({ dm: dmMulti, mv: ammo.mv }),
        });
        const hit = await calc.fire({
            shot: multiShot,
            trajectoryRange: range,
            trajectoryStep: step,
        });
        const multiTrajectory = hit.samples;

        for (let i = 0; i < multiTrajectory.length; i++) {
            expect(multiTrajectory[i].formatted()).toEqual(baselineTrajectory[i].formatted());
        }
    });

    test("mbc2", async () => {
        const dmMulti = DragModelMultiBC({
            bcPoints: [
                new BCPoint({ BC: 0.22, V: UNew.FPS(2700) }),
                new BCPoint({ BC: 0.5, V: UNew.FPS(3500) }),
            ],
            dragTable: DragTables.G7,
        });
        const multiShot = new Shot({
            weapon: weapon,
            ammo: new Ammo({ dm: dmMulti, mv: ammo.mv }),
        });
        const hit = await calc.fire({
            shot: multiShot,
            trajectoryRange: range,
            trajectoryStep: step,
        });
        const multiTrajectory = hit.samples;

        for (let i = 0; i < multiTrajectory.length; i++) {
            expect(multiTrajectory[i].formatted()).toEqual(baselineTrajectory[i].formatted());
        }
    });

    test("mbc3", async () => {
        const dmMulti = DragModelMultiBC({
            bcPoints: [
                new BCPoint({ BC: 0.5, V: baselineTrajectory[3].velocity }),
                new BCPoint({ BC: 0.22, V: baselineTrajectory[2].velocity }),
            ],
            dragTable: DragTables.G7,
        });
        const multiShot = new Shot({
            weapon: weapon,
            ammo: new Ammo({ dm: dmMulti, mv: ammo.mv }),
        });
        const hit = await calc.fire({
            shot: multiShot,
            trajectoryRange: range,
            trajectoryStep: step,
        });
        const multiTrajectory = hit.samples;

        expect(multiTrajectory[1].velocity.rawValue).toBeCloseTo(
            baselineTrajectory[1].velocity.rawValue,
            1e-5
        );
        expect(multiTrajectory[4].velocity.rawValue).toBeGreaterThan(
            baselineTrajectory[4].velocity.rawValue
        );
    });

    test("mbc", () => {
        const dmMulti = DragModelMultiBC({
            bcPoints: [
                new BCPoint({ BC: 0.275, V: UNew.MPS(800) }),
                new BCPoint({ BC: 0.255, V: UNew.MPS(500) }),
                new BCPoint({ BC: 0.26, V: UNew.MPS(700) }),
            ],
            dragTable: DragTables.G7,
            weight: 178,
            diameter: 0.308,
        });

        expect(dmMulti.dragTable[0].CD).toBeCloseTo(0.1259323091692403, 1e-8);
        expect(dmMulti.dragTable[dmMulti.dragTable.length - 1].CD).toBeCloseTo(
            0.1577125859466895,
            1e-8
        );
    });

    test("valid", () => {
        const dmMulti = DragModelMultiBC({
            bcPoints: [
                new BCPoint({ BC: 0.417, V: UNew.MPS(745) }),
                new BCPoint({ BC: 0.409, V: UNew.MPS(662) }),
                new BCPoint({ BC: 0.4, V: UNew.MPS(580) }),
            ],
            dragTable: DragTables.G7,
            weight: 285,
            diameter: 0.338,
        });

        const cds = dmMulti.dragTable.map((p) => p.CD);
        const machs = dmMulti.dragTable.map((p) => p.Mach);

        const reference = [
            [1, 0.3384895315],
            [2, 0.2585639866],
            [3, 0.2069547831],
            [4, 0.1652052415],
            [5, 0.1381406102],
        ];

        reference.forEach(([mach, cd]) => {
            const idx = machs.indexOf(mach);

            // Subtest equivalent using individual expect statements
            expect(cds[idx]).toBeCloseTo(cd, 1e-3); // Precision of 3 decimal places
        });
    });
});
